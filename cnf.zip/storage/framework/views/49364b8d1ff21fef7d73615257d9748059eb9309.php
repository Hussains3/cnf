<?php $__env->startSection('content'); ?>
    <div style="margin: 0 15%;">
        <div class="card card-accent-primary mb-3 text-left" style="">
            <div class="card-header">Add Salary</div>
            <div class="card-body text-primary">

            <?php echo Form::open(['route' => 'salary.store', 'method' => 'post', 'enctype' => 'multipart/form-data' ]); ?>


            <?php echo e(csrf_field()); ?>


            <div class="row">

                <div class="form-group col-6">
                    <?php echo e(Form::label('user_id','User Name')); ?>

                    <?php echo Form::select('user_id', $users, null, ['class'=>'form-control', 'required']); ?>


                    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group col-6 ">
                    <?php echo e(Form::label('year', 'Year')); ?>

                    <div class="input-group mb-3">
                        <?php echo e(Form::text('year', date('Y'), array('class' => 'form-control','required'  ))); ?>

                        <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>


                <!-- Month Input Form -->
                <div class="form-group col-6">
                    <?php echo e(Form::label('month','Month')); ?>

                    <select name="month" class="form-control" id="month" required="">
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>

                    <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <!-- Destination Input Form -->
                <div class="form-group col-6">
                    <?php echo e(Form::label('working_days','Working Day')); ?>


                    <?php echo e(Form::number('working_days', 26, ['class' => 'form-control', 'placeholder' => 'Working day', 'required'])); ?>


                    <?php $__errorArgs = ['working_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <!-- Destination Input Form -->
                <div class="form-group col-6">
                    <?php echo e(Form::label('holiday','Leave/Absent')); ?>


                    <?php echo e(Form::number('holiday', 0, ['class' => 'form-control', 'placeholder' => 'Absent Day', 'required'])); ?>


                    <?php $__errorArgs = ['holiday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>



                <hr>
                <div class="col-12">
                    <div class="text-right">
                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>


            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/salary/create.blade.php ENDPATH**/ ?>