<!DOCTYPE html>
<html>
<title>Email</title>
<body>
    <h1>Mail Testing with data</h1>
    <p>B/E Number: <?php echo e($email_data['be_number']); ?></p>
    <p>B/E Date: <?php echo e($email_data['be_date']); ?></p>
    <p><?php echo e($email_data['ie_type']); ?>: <?php echo e($email_data['ie_name']); ?></p>
    <p>Manifest No: <?php echo e($email_data['manifest_no']); ?></p>
    <p>Manifest Date: <?php echo e($email_data['manifest_date']); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\cnf\resources\views/emails/mail.blade.php ENDPATH**/ ?>