<?php $__env->startSection('content'); ?>

    <h2 id="tr" class="text-center">Daily Report</h2>
    <p class="text-center"><?php echo e($date); ?></p>
    <div class="card-header">
        <div class="row">
            <div class="col-md-10">
                <?php echo Form::open(['route' => 'get_daily_report', 'method' => 'post']); ?>

                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-md-2 d-flex align-items-center justify-content-end">
                        <label>Date</label>
                    </div>
                    <div class="col-md-8">
                        <?php echo Form::date('to_date', Carbon\Carbon::today(), ['id'=>'to_date', 'class'=>'form-control']); ?>

                    </div>

                    <div class="col-md-2 text-center">
                        <?php echo Form::submit('Filter', ['class'=>'btn btn-primary', 'style'=>'padding: .3rem 1rem;']); ?>

                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="col-md-2">
                <?php if(!empty($file_datas)): ?>
                    <button class="btn btn btn-secondary" onclick="printDiv('printMe')"> Print Report</button>
                <?php endif; ?>
            </div>
        </div>


    </div>
    <?php if($file_datas->isNotEmpty() ): ?>
    <div class="" id="printMe">
        <table id="daily_report" class="table table-striped table-bordered " style="width:100%">
            <thead>
                <tr>
                    <th>Sirial</th>
                    <th>Operator Name</th>
                    <th>Importer</th>
                    <th>Agent</th>
                    <th>B/E No</th>
                    <th>B/E Date</th>
                    <th>Taka</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $file_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e(( $file_data->operator->name ) ?? null); ?></td>
                <td><?php echo e(( $file_data->ie_data->name ) ?? null); ?></td>
                <td><?php echo e($file_data->agent->name); ?></td>
                <td><?php echo e($file_data->be_number); ?></td>
                <td><?php echo e($file_data->be_date); ?></td>
                <td><?php echo e($file_data->fees); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td></td>
                <td></td>
                <td></td>
                <th>Toral: B/E </th>
                <th><?php echo e($total_file); ?></th>
                <th>Toral Taka: </th>
                <th><?php echo e($total_amount); ?></th>
            </tr>


            <tfoot>

            <tr class="d-none">
                <th>ID</th>
                <th>Operator Name</th>
                <th>Importer</th>
                <th>Agent</th>
                <th>B/E No</th>
                <th>B/E Date</th>
                <th>Taka</th>
            </tr>
            </tfoot>
        </table>
    </div>

    <?php else: ?>
        <h2 class="text-center">No Data Found</h2>
        <p class="mt-2 text-center">
            <a class="btn btn-sm btn-info" href="/file_datas/create">Receive a new file</a>
        </p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.20/filtering/row-based/range_dates.js"></script>

    <script>

        function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;

    }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/reports/daily_report.blade.php ENDPATH**/ ?>