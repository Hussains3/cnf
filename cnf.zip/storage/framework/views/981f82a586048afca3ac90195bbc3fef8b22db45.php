<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  <!-- Styles -->
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet" media='screen,print'>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" media='screen,print'>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-flash-1.6.1/b-html5-1.6.1/b-print-1.6.1/datatables.min.css"/>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" integrity="sha256-rByPlHULObEjJ6XQxW/flG2r+22R5dKiAoef+aXWfik=" crossorigin="anonymous" />

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

</head>

<body>
<div class="wrapper">

    <!-- Sidebar  -->
    <nav id="sidebar">
        <div class="sidebar-header">

            <h1 class="text-center">C&F</h1>
        </div>

        <ul class="list-unstyled components">
            <p><a href="/">DASHBOARD</a></p>
            <li class="accordion" id="accordionExample">

                <hr style="margin: 0;">
                
                <a href="#agentSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" data-target="#agentSubmenu" >Agents</a>
                <ul class="<?php echo e(Request::path() === 'agents' || Request::path() === 'agents/create' ? 'show ' : ''); ?>collapse list-unstyled" data-parent="#accordionExample" id="agentSubmenu">
                    <li>
                        <a href="/agents">All Agents</a>
                    </li>
                    <li>
                        <a href="/agents/create">New Agent</a>
                    </li>
                </ul>

                <hr style="margin: 0;">
                
                <a href="#ieSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" data-target="#ieSubmenu" >Importer / Exporter</a>
                <ul class="<?php echo e(Request::path() === 'ie_datas' || Request::path() === 'ie_datas/create' ? 'show ' : ''); ?>collapse list-unstyled" data-parent="#accordionExample" id="ieSubmenu">
                    <li>
                        <a href="/ie_datas">Importer/Exporter List</a>
                    </li>
                    <li>
                        <a href="/ie_datas/create">New Importer/Exporter</a>
                    </li>
                </ul>


                <hr style="margin: 0;">
                
                <a href="#dataSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" data-target="#dataSubmenu" >File Datas</a>
                <ul class="<?php echo e(Request::path() === 'file_edit' || Request::path() === 'file_list' || Request::path() === 'file_datas' || Request::path() === 'file_datas/create' ? 'show ' : ''); ?>collapse list-unstyled" data-parent="#accordionExample" id="dataSubmenu">
                    <?php if (app('laratrust')->hasRole('admin|receiver')) : ?>
                        <li>
                            <a href="/file_datas/create">File Receive</a>
                        </li>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <li>
                        <a href="/file_datas">
                            <?php if (app('laratrust')->hasRole('admin')) : ?>
                                List Data
                            <?php endif; // app('laratrust')->hasRole ?>
                            <?php if (app('laratrust')->hasRole('receiver|operator')) : ?>
                                Received Data
                            <?php endif; // app('laratrust')->hasRole ?>
                            <?php if (app('laratrust')->hasRole('deliver')) : ?>
                                Operated Data
                            <?php endif; // app('laratrust')->hasRole ?>
                        </a>
                    </li>

                    <?php if (app('laratrust')->hasRole('admin|operator|deliver')) : ?>
                        <li>
                            <a href="/file_list">Edit Datas</a>
                        </li>
                    <?php endif; // app('laratrust')->hasRole ?>

                </ul>




                <hr style="margin: 0;">
                

                <a href="#reportSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" data-target="#reportSubmenu">Reports</a>
                <ul class="<?php echo e(Request::path() === 'deliver_report' || Request::path() === 'operator_report'|| Request::path() === 'receiver_report'); ?>collapse list-unstyled" data-parent="#accordionExample" id="reportSubmenu">
                    <li>
                        <a href="/deliver_report">Delivery Report</a>
                    </li>
                    <li>
                        <a href="/operator_report">Operator Report</a>
                    </li>
                    <li>
                        <a href="/receiver_report">Receiver Report</a>
                    </li>

                    <li>
                        <a href="/data_entry">Data Entry Report</a>
                    </li>

                </ul>
                <hr style="margin: 0;">
                <a href="/support">Support</a>
            </li>
        </ul>


        <ul class="list-unstyled CTAs">
            <li>
                <a class="download dropdown-item" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>

            </li>

        </ul>
    </nav>

    <!-- Page Content  -->
    <div id="content" >
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <i class="fas fa-align-left"></i>
                    
                </button>
                <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-align-justify"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ml-auto">

                        <li class="nav-item active">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
<span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>



                    </ul>
                </div>
            </div>
        </nav>

        <div id="content-main" style="min-height: calc(100vh - 165px);">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- Footer -->
        <footer class="page-footer font-small" style="background: #e9ecef">

            <!-- Copyright -->
            <div class="footer-copyright text-center py-3 ">© 2020 Copyright:
                <a href="http://softxltd.com/"> SoftxLtd.com</a>
            </div>
            <!-- Copyright -->

        </footer>
        <!-- Footer -->


    </div>
</div>


<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>


<script src="<?php echo e(asset('js/admin.js')); ?>" ></script>
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-flash-1.6.1/b-html5-1.6.1/b-print-1.6.1/datatables.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" integrity="sha256-KM512VNnjElC30ehFwehXjx1YCHPiQkOPmqnrWtpccM=" crossorigin="anonymous"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $("#sidebar").mCustomScrollbar({
            theme: "minimal"
        });

        $('#sidebarCollapse').on('click', function () {
            $('#sidebar, #content').toggleClass('active');
            $('.collapse.in').toggleClass('in');
            $('a[aria-expanded=true]').attr('aria-expanded', 'false');
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.7.1/dist/sweetalert2.all.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.select2_op').select2();
        });
    </script>

    <script>
        $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\DJ\laragon\www\CNF\resources\views/layouts/admin.blade.php ENDPATH**/ ?>