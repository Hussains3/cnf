<?php $__env->startSection('content'); ?>
<style>
    @media  print {
        *{margin:0;padding:0;}
        .pdn {
            display: none;
        }
        .pbg{
            background-color: gray;
        }
        .date{
            text-align: left !important;
        }
    }
</style>

<div class="print" id="print">
    <div class="row mt-5">
        <div class="col-12 text-center">
            <h4>BENAPOLE CUSTOMS C&F AGENTS ASSOCIATION</h4>
        </div>
        <hr>
        <div class="col-12 text-center mb-5">
            <h5 class="pbg">DAILY REPORT</h5>
        </div>
        <div class="col-12 date text-center">Date: <?php echo e($date); ?></div>

    </div>
    <div class="row card pdn">
        <div class="card-header">
            <?php echo Form::open(['route' => 'get_daily_summary', 'method' => 'post']); ?>

            <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-12">
                        <div class="form-group form-inline m-0">
                            <?php echo Form::label('date','Date'); ?>

                            <?php echo Form::date('date', $date , ['class'=>'form-control mx-2']); ?>

                            <?php echo Form::submit('Filter', ['class'=>'btn btn-primary mx-2','style'=>'padding: .3rem 1rem;']); ?>

                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
    <div class="row mt-5">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <table id="data" class="table is-narrow table-striped table-bordered">
                <thead>
                <tr>
                    <th class="text-center">Total B/E</th>
                    <th class="text-center">Total Taka</th>
                </tr>
                </thead>

                <tbody>
                <tr>
                    <th class="text-center"><?php echo e($total_file); ?></th>
                    <th class="text-center"><?php echo e($total_amount); ?></th>
                </tr>

                </tbody>
            </table>
        </div>
        <div class="col-md-4"></div>

    </div>
    <hr>
<button class="pdn btn btn-info text-center" style="" onclick="printDiv()">Print</button>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function printDiv() {
            Popup($('#print').outerHTML);
            function Popup(data)
            {
                window.print();
                return true;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/reports/daily_summary.blade.php ENDPATH**/ ?>