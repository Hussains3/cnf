<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col">
            <h2>Deactivated Agents</h2>
        </div>
        <div class="col text-right">

            <a href="<?php echo e(route('agents.create')); ?>" class="btn btn-primary">
                <i class="mdi mdi-account-edit"></i> New Agent</a>
        </div>
    </div>

    <div class="card-content">
        <table id="agent" class="table is-narrow">
            <thead>
            <tr>
                <th>No</th>
                <th>Ain No</th>
                <th>Agent Name</th>
                <th>Owner Name</th>
                <th>Photo</th>
                <th>Designation</th>
                <th>Office_address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>House / Station</th>
                <th>Action</th>
            </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $tAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <th><?php echo e(++$i); ?> </th>
                    <td><?php echo e($agent->ain_no); ?></td>
                    <td><?php echo e($agent->name); ?></td>
                    <td><?php echo e($agent->owners_name); ?></td>
                    <td><a target="_blank" href="/<?php echo e($agent->photo); ?>"><img src="/<?php echo e($agent->photo); ?>" alt="" width="40"></a></td>
                    <td><?php echo e($agent->destination); ?></td>
                    <td><?php echo e($agent->office_address); ?></td>
                    <td><?php echo e($agent->phone); ?></td>
                    <td><?php echo e($agent->email); ?></td>
                    <td><?php echo e($agent->house); ?></td>
                    <td class="has-text-right">
                        

                        <form action="<?php echo e(route('agents.destroy',$agent->id)); ?>" method="POST">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            

                            <?php if (app('laratrust')->hasRole('admin')) : ?>
                            
                            <?php endif; // app('laratrust')->hasRole ?>




                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('#agent').DataTable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/agents/trash.blade.php ENDPATH**/ ?>