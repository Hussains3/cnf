<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col">
            <h2>Product Types</h2>
        </div>
        <div class="col text-right">

            <a href="<?php echo e(route('product_types.create')); ?>" class="btn btn-primary">
                <i class="mdi mdi-account-edit"></i>Product Types</a>
        </div>
    </div>

    <div class="card-content">
        <table id="suppliers" class="table is-narrow">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Note</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $product_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e(++$i); ?> </th>
                    <td><?php echo e($product_type->name); ?></td>
                    <td><?php echo e($product_type->note); ?></td>

                    <td class="has-text-right">
                        

                        <form action="<?php echo e(route('suppliers.destroy',$product_type->id)); ?>" method="POST">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            

                            <a class="btn btn-info" href="<?php echo e(route('product_types.edit', $product_type->id)); ?>"> Edit</a>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('#suppliers').DataTable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DJ\laragon\www\CNF\resources\views/datas/index.blade.php ENDPATH**/ ?>