<?php $__env->startSection('content'); ?>

<h1>Create New User</h1>
<hr>

  <?php echo Form::open(['route' => 'users.store', 'method' => 'post']); ?>

  <?php echo e(csrf_field()); ?>

  <div class="row">

    <div class="col-md-7">

      <?php echo e(Form::label('name', 'Full Name')); ?>

      <div class="input-group mb-3">        
        <?php echo e(Form::text('name', null, array('class' => 'form-control', 'placeholder' => 'Full Name'))); ?>

      </div>

      <?php echo e(Form::label('email', 'Your Email')); ?>

      <div class="input-group mb-3">
        <?php echo e(Form::email('email', null, array('class' => 'form-control','placeholder' => 'example@mail.com'))); ?>

      </div>

      <?php echo e(Form::label('password', 'Password')); ?>

      <div class="input-group mb-3">
        <?php echo e(Form::text('password', null, ['class' => 'form-control','placeholder' => 'Password'])); ?>

      </div>
    </div>
    <div class="col-md-1">
      
    </div>
    <div class="col-md-4">
        <label for="roles">Roles</label>
        <hr>

        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="input-group mb-3 ml4">
              <?php echo e(Form::checkbox('roles', $role->id, ['class' => 'form-check-input'] )); ?> &nbsp; <?php echo e($role->display_name); ?>

          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
  </div>  
  <hr>
  <div class="btnsub text-right">
    <?php echo e(Form::submit('Create User', ['class' => 'btn btn-primary'])); ?>

  </div>
<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/manage/users/create.blade.php ENDPATH**/ ?>