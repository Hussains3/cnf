<?php $__env->startSection('content'); ?>

    <div style="margin: 0 15%;">

        <div class="card card-accent-primary mb-3 text-left mt-5" style="">
            <div class="card-header">Data Entry -
                <?php if (app('laratrust')->hasRole('receiver')) : ?>
                    Receiver Part
                <?php endif; // app('laratrust')->hasRole ?>
                <?php if (app('laratrust')->hasRole('operator')) : ?>
                    Operator Part
                <?php endif; // app('laratrust')->hasRole ?>
                <?php if (app('laratrust')->hasRole('deliver')) : ?>
                    Delivery Part
                <?php endif; // app('laratrust')->hasRole ?>
            </div>
            <div class="card-body text-primary">
                <?php echo e(Form::model($file_data, ['route' => ['file_datas.update', $file_data->id], 'method' => 'put','enctype' => 'multipart/form-data'])); ?>


                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <?php if (app('laratrust')->hasRole('admin|receiver|operator|deliver')) : ?>
                    <div class="form-group col-6">
                        <?php echo e(Form::label('lodgement_no', 'Lodgement No')); ?>

                        <div class="input-group mb-3">
                            <span style="padding-top: 5px;padding-right: 10px"><?php echo e(date('Y')); ?> - </span><?php echo e(Form::text('lodgement_no', null, array('class' => 'form-control', 'placeholder' => 'Lodgement No', 'required'  ))); ?>

                        </div>
                    </div>

                    <div class="form-group col-6">
                        <?php echo e(Form::label('lodgement_date', 'Lodgement Date')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::date('lodgement_date', \Carbon\Carbon::now(), array('class' => 'form-control', 'placeholder' => 'Lodgement Date', 'required'  ))); ?>

                        </div>
                    </div>

                    <div class="form-group col-6">
                        <?php echo e(Form::label('manifest_no', 'Manifest No')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('manifest_no', null, array('class' => 'form-control', 'placeholder' => 'Manifest No', 'required'  ))); ?>

                        </div>
                    </div>

                    <div class="form-group col-6">
                        <?php echo e(Form::label('manifest_date', 'Manifest Date')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::date('manifest_date', \Carbon\Carbon::now(), array('class' => 'form-control', 'placeholder' => 'Manifest Date', 'required'  ))); ?>

                        </div>
                    </div>

                    <div class="form-group col-6">
                        <?php echo e(Form::label('agent_id', 'Select Agent')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::select('agent_id', $agents, null, array('class' => 'opt_sel2 form-control', 'placeholder' => 'Select Agent', 'required'  ))); ?>

                        </div>
                    </div>

                    <div class="form-group col-6">
                        <?php echo e(Form::label('group', 'Group (Import/Export)')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('group', null, array('class' => 'form-control', 'placeholder' => 'Group', 'required'  ))); ?>

                        </div>
                    </div>

                    
                    <?php endif; // app('laratrust')->hasRole ?>

                    <?php if (app('laratrust')->hasRole('admin|operator|deliver')) : ?>
                    <div class="card-accent-primary col-12 mb-3"></div>

                    <!-- Import / Export Input Form -->
                    <div class="form-group col-4">
                        <?php echo e(Form::label('ie_type','File Type (Import / Export:) ')); ?> <br>
                        <div class="radio radio-inline">
                            <span> </span>
                            <label>
                                <?php echo e(Form::radio('ie_type', 'Import', true)); ?> Import
                            </label>
                            <label>
                                <?php echo e(Form::radio('ie_type', 'Export')); ?> Export
                            </label>

                        </div>
                    </div>

                    <div class="form-group col-4">
                        <?php echo e(Form::label('bin_no','BIN No:')); ?>


                        <?php echo e(Form::text('bin_no', $file_data->ie_data->bin_no ?? null, ['class' => 'form-control', 'placeholder' => 'BIN No'])); ?>


                        <?php $__errorArgs = ['bin_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    <div class="form-group col-4 ">
                        <?php echo e(Form::label('name', 'Importer / Exporter Name')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('name', $file_data->ie_data->name ?? '', array('class' => 'form-control', 'placeholder' => 'Importer / Exporter Name', 'required'  ))); ?>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group col-4 ">
                        <?php echo e(Form::label('owners_name', 'Owner / Manager Name')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('owners_name', $file_data->ie_data->owners_name ?? '', array('class' => 'form-control', 'placeholder' => 'Owner Name'))); ?>

                            <?php $__errorArgs = ['owners_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <!-- Photo Input Form -->
                    <div class="form-group col-4">
                        <?php echo e(Form::label('photo','Photo:')); ?>

                        <?php echo e(Form::file('photo', null)); ?>

                        <p class="help-block"></p>
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <!-- Destination Input Form -->
                    <div class="form-group col-4">
                        <?php echo e(Form::label('destination','Designation:')); ?>


                        <?php echo e(Form::text('destination', $file_data->ie_data->destination ?? '', ['class' => 'form-control', 'placeholder' => 'Destination'])); ?>


                        <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Destination Input Form -->
                    <div class="form-group col-8">
                        <?php echo e(Form::label('office_address','Agent / Office Address:')); ?>


                        <?php echo e(Form::text('office_address', $file_data->ie_data->office_address ?? '', ['class' => 'form-control', 'placeholder' => 'Office Address'])); ?>


                        <?php $__errorArgs = ['office_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Phone Number Input Form -->
                    <div class="form-group col-4">
                        <?php echo e(Form::label('phone','Phone Number:')); ?>


                        <?php echo e(Form::text('phone', $file_data->ie_data->phone ?? '', ['class' => 'form-control', 'placeholder' => 'Agent Phone Number'])); ?>


                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Email Input Form -->
                    <div class="form-group col-4 ">
                        <?php echo e(Form::label('email','Email:')); ?>


                        <?php echo e(Form::email('email', $file_data->ie_data->email ?? '', ['class' => 'form-control', 'placeholder' => 'Email'])); ?>


                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Phone Number Input Form -->
                    <div class="form-group col-8">
                        <?php echo e(Form::label('house','House / Station')); ?>


                        <?php echo e(Form::text('house','Benapol', ['class' => 'form-control', 'placeholder' => 'Benapol', 'required'])); ?>


                        <?php $__errorArgs = ['house'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <div class="card-accent-primary col-12 mb-3"></div>
                    <div class="form-group col-4">
                        <?php echo e(Form::label('goods_name', 'Goods Name')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('goods_name', null, array('class' => 'form-control', 'placeholder' => 'Goods Name'))); ?>

                        </div>
                    </div>

                    <div class="form-group col-4">
                        <?php echo e(Form::label('goods_type', 'Goods Type')); ?>

                        <div class="input-group mb-3">
                            

                            <?php echo e(Form::radio('goods_type', 'Perishable', true,['class' => 'form-control','required'])); ?>

                            <?php echo e(Form::label('Perishable')); ?>


                            <?php echo e(Form::radio('goods_type', 'Non-Perishable', true,['class' => 'form-control','required'])); ?>

                            <?php echo e(Form::label('Non-Perishable')); ?>

                        </div>
                    </div>

                    <div class="form-group col-4">
                        <?php echo e(Form::label('be_number', 'B/E Number')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('be_number', null, array('class' => 'form-control','min'=>'3', 'placeholder' => 'B/E Number', 'required'  ))); ?>


                        </div>
                    </div>

                    <div class="form-group col-4">
                        <?php echo e(Form::label('be_date', 'B/E Date')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::date('be_date', \Carbon\Carbon::now(), array('class' => 'form-control', 'placeholder' => 'be_date'))); ?>

                        </div>
                    </div>


                    <div class="form-group col-4">
                        <?php echo e(Form::label('page', 'Item')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::number('page', null,['class' => 'form-control', 'placeholder' => 'maximum 299', 'required','max'=>'299'])); ?>

                        </div>
                    </div>

                    <div class="form-group col-4">
                        <?php echo e(Form::label('fees', 'Fees /=')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::number('fees', '230',['class' => 'form-control', 'placeholder' => '230/='])); ?>

                        </div>
                    </div>

                    <?php endif; // app('laratrust')->hasRole ?>

                    <hr>
                    <?php if (app('laratrust')->hasRole('operator')) : ?>

                    <div class="form-group col-12">
                        <div class="text-right">
                            <?php echo e(Form::submit('Operate', ['class' => 'btn btn-primary'])); ?>

                        </div>
                    </div>
                    <?php endif; // app('laratrust')->hasRole ?>
                    <?php if (app('laratrust')->hasRole('deliver')) : ?>

                        <div class="form-group col-12">
                            <div class="text-right">
                                
                                
                                <button type="submit" name="action" class="btn btn-secondary mx-2" value="print">Deliver and Print</button>
                                
                            </div>
                        </div>
                    <?php endif; // app('laratrust')->hasRole ?>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
        

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
            $('.opt_sel2').select2();
        });
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/file_datas/edit.blade.php ENDPATH**/ ?>