<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  <!-- Styles -->
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet" media='screen,print'>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" media='screen,print'>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-flash-1.6.1/b-html5-1.6.1/b-print-1.6.1/datatables.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" integrity="sha256-rByPlHULObEjJ6XQxW/flG2r+22R5dKiAoef+aXWfik=" crossorigin="anonymous" />

    <!-- Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" integrity="sha512-F5QTlBqZlvuBEs9LQPqc1iZv2UMxcVXezbHzomzS6Df4MZMClge/8+gXrKw2fl5ysdk4rWjR0vKS7NNkfymaBQ==" crossorigin="anonymous"></script>

</head>

<body>
<div class="wrapper">

    <!-- Sidebar  -->

    <nav id="sidebar">
        <div class="sidebar-header d-flex justify-content-center">
            <img src="<?php echo e(asset('images/app_logo.png')); ?>" alt="C&F" width="70">
            
        </div>

        <ul class="list-unstyled components">
            <p><a href="/">DASHBOARD</a></p>
            <li class="accordion" id="accordionExample">

                <hr style="margin: 0;">
                
                <a href="#agentSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" data-target="#agentSubmenu" >Agents</a>
                <ul class="<?php echo e(Request::path() === 'agents' || Request::path() === 'agents/create' ? 'show ' : ''); ?>collapse list-unstyled" data-parent="#accordionExample" id="agentSubmenu">
                    <li>
                        <a href="/agents">All Agents</a>
                    </li>
                    <?php if (app('laratrust')->hasRole('admin')) : ?>
                    <li>
                        <a href="/agents/create">New Agent</a>
                    </li>

                    <li>
                        <a href="/showDeactive">Deactivated Agents</a>
                    </li>
                    <?php endif; // app('laratrust')->hasRole ?>
                </ul>


                <hr style="margin: 0;">
                
                <a href="#ieSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" data-target="#ieSubmenu" >Importer / Exporter</a>
                <ul class="<?php echo e(Request::path() === 'ie_datas' || Request::path() === 'ie_datas/create' ? 'show ' : ''); ?>collapse list-unstyled" data-parent="#accordionExample" id="ieSubmenu">
                    <li>
                        <a href="/ie_datas">Importer/Exporter List</a>
                    </li>
                    <li>
                        <a href="/ie_datas/create">New Importer/Exporter</a>
                    </li>
                </ul>


                <hr style="margin: 0;">
                
                <a href="#dataSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"  >File Datas</a>
                <ul class="<?php echo e(Request::path() === 'file_edit' || Request::path() === 'file_list' || Request::path() === 'file_datas' || Request::path() === 'file_datas/create' ? 'show ' : ''); ?>collapse list-unstyled"  id="dataSubmenu">
                    <?php if (app('laratrust')->hasRole('admin|receiver')) : ?>
                        <li>
                            <a href="/file_datas/create">File Receive</a>
                        </li>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <li>
                        <a href="/file_datas">
                            <?php if (app('laratrust')->hasRole('admin')) : ?>
                                List Data
                            <?php endif; // app('laratrust')->hasRole ?>
                            <?php if (app('laratrust')->hasRole('receiver|operator')) : ?>
                                Received Data
                            <?php endif; // app('laratrust')->hasRole ?>
                            <?php if (app('laratrust')->hasRole('deliver')) : ?>
                                Operated Data
                            <?php endif; // app('laratrust')->hasRole ?>
                        </a>
                    </li>
                </ul>
                <?php if (app('laratrust')->hasRole('operator')) : ?>
                
                <a href="<?php echo e(route('gfiles.index')); ?>" class=""  >Green Files</a>
                <?php endif; // app('laratrust')->hasRole ?>
                <?php if (app('laratrust')->hasRole('admin')) : ?>
                <a href="#userSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"  >User</a>
                <ul class="<?php echo e(Request::path() === 'user' || Request::path() === 'user_adde' ? 'show ' : ''); ?>collapse list-unstyled"  id="userSubmenu">
                    <li>
                        <a href="<?php echo e(route('users.index')); ?>">Users List</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('users.create')); ?>">Add User</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('salary.create')); ?>">Add Salary</a>
                    </li>
                </ul>
                <?php endif; // app('laratrust')->hasRole ?>



                <hr style="margin: 0;">

                

                <a href="#reportSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" data-target="#reportSubmenu">Reports</a>
                <ul class="<?php echo e(Request::path() === 'data_entry' ||  Request::path() === 'export_report' || Request::path() === 'import_report' || Request::path() === 'goods_report' ||Request::path() === 'daily_report' || Request::path() === 'daily_summary' || Request::path() === 'deliver_report' || Request::path() === 'operator_report'|| Request::path() === 'receiver_report'); ?>collapse list-unstyled" data-parent="#accordionExample" id="reportSubmenu">
                    <li>
                        <a href="/receiver_report">Receiver Report</a>
                    </li>
                    <li>
                        <a href="/import_report">Delivery Report (import)</a>
                    </li>
                    <li>
                        <a href="/export_report">Delivery Report (Export)</a>
                    </li>
                    <li>
                        <a href="/daily_summary">Daily Summary Report</a>
                    </li>
                    <li>
                        <a href="/daily_report">Daily Report</a>
                    </li>
                    <li class="d-none">
                        <a href="/operator_report">Operator Report</a>
                    </li>

                    <li>
                        <a href="/data_entry">Data Entry Report</a>
                    </li>

                    <li>
                        <a href="/monthly_final_report">Monthly Final Report</a>
                    </li>
                    <li>
                        <a href="/goods_report">Assessment Report Per Day</a>
                    </li>
                    <li>
                        <a href="/work_report_per_day">Work Report Per Day</a>
                    </li>

                </ul>

                <hr style="margin: 0;">
                <a href="/support">Support</a>
            </li>
        </ul>
        <ul class="list-unstyled CTAs">
            <li>
                <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>

            </li>

        </ul>
    </nav>

    <!-- Page Content  -->
    <div id="content" >
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid d-flex justify-content-between text-center">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <i class="fas fa-align-left"></i>
                </button>
                
                <h1 class="text-uppercase w-75 text-primary">Benapole customs c&F agents association</h1>

                <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarSupportedContent">
                    <ul class="nav navbar-nav">

                        <li class="nav-item active">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div id="content-main" style="min-height: calc(100vh - 165px);">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- Footer -->
        <footer class="page-footer font-small" style="background: #e9ecef">

            <!-- Copyright -->
            <div class="footer-copyright text-center py-3 ">© 2020 Copyright:
                <a href="http://softxltd.com/"> SoftxLtd.com</a>
            </div>
            <!-- Copyright -->

        </footer>
        <!-- Footer -->


    </div>
</div>


<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>


<script src="<?php echo e(asset('js/admin.js')); ?>" ></script>
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-flash-1.6.1/b-html5-1.6.1/b-print-1.6.1/datatables.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" integrity="sha256-KM512VNnjElC30ehFwehXjx1YCHPiQkOPmqnrWtpccM=" crossorigin="anonymous"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $("#sidebar").mCustomScrollbar({
            theme: "minimal"
        });

        $('#sidebarCollapse').on('click', function () {
            $('#sidebar, #content').toggleClass('active');
            $('.collapse.in').toggleClass('in');
            $('a[aria-expanded=true]').attr('aria-expanded', 'false');
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.7.1/dist/sweetalert2.all.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.select2_op').select2();
        });
    </script>

    <script>
        $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\cnf\resources\views/layouts/admin.blade.php ENDPATH**/ ?>