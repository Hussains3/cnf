

<?php $__env->startSection('content'); ?>

<div class="flex-container">
    <div class="columns m-t-10">
      <div class="column">
        <h1 class="title">Manage Users</h1>
      </div>
      <div class="column text-right">
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-outline-primary">
            <i class="mdi mdi-account-edit"></i> Create New User</a>
      </div>
    </div>
    <hr class="m-t-0">

    <div class="card">
      <div class="card-content">
        <table class="table is-narrow">
          <thead>
            <tr>
              <th>id</th>
              <th>Counter No</th>
              <th>Name</th>
              <th>Email</th>
              <th>Date Created</th>
              <th></th>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($user->id); ?></th>
                <td><?php echo e($user->counter); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->created_at->toFormattedDateString()); ?></td>
                <td class="has-text-right"><a class="btn btn-outline-success" href="<?php echo e(route('users.show', $user->id)); ?>">View </a> <a class="btn btn-outline-info" href="<?php echo e(route('users.edit', $user->id)); ?>"> Edit</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div> <!-- end of .card -->

    <?php echo e($users->links()); ?>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/manage/users/index.blade.php ENDPATH**/ ?>