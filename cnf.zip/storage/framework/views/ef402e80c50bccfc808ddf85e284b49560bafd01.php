<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('css/db.css')); ?>" rel="stylesheet">

    <div class="jumbotron">
        <div class="row w-100">
            <div class="col-md-3 col-sm-4">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/file_datas">
                        <div class="wrimagecard-topimage_header text-center fsi" style="background-color:  rgba(51, 105, 232, 0.1)">
                            <i class="fas fa-list" style="color:#3369e8"></i>
                        </div>
                        <div class="wrimagecard-topimage_title">
                            <h4>Files
                                <div class="pull-right badge" id="WrGridSystem"></div></h4>
                        </div>

                    </a>
                </div>
            </div>
            <?php if (app('laratrust')->hasRole('receiver')) : ?>

            <div class="col-md-3 col-sm-4">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/file_datas/create">
                        <div class="wrimagecard-topimage_header text-center fsi" style="background-color: rgba(22, 160, 133, 0.1)">
                            <i class = "fas fa-cart-arrow-down" style="color:#16A085"></i>
                        </div>
                        <div class="wrimagecard-topimage_title">
                            <h4>New File
                                <div class="pull-right badge" id="WrControls"></div></h4>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; // app('laratrust')->hasRole ?>
            <div class="col-md-3 col-sm-4">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/ie_datas">
                        <div class="wrimagecard-topimage_header text-center fsi" style="background-color:  rgba(51, 105, 232, 0.1)">
                            <i class="fas fa-shopping-bag" style="color:#3369e8"> </i>
                        </div>
                        <div class="wrimagecard-topimage_title">
                            <h4>Import / Export
                                <div class="pull-right badge" id="WrGridSystem"></div></h4>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-md-3 col-sm-4">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/agents">
                        <div class="wrimagecard-topimage_header text-center fsi" style="background-color: rgba(22, 160, 133, 0.1)">
                            <i class = "fas fa-users" style="color:#16A085"></i>
                        </div>
                        <div class="wrimagecard-topimage_title">
                            <h4>Agents
                                <div class="pull-right badge" id="WrControls"></div>
                            </h4>
                        </div>
                    </a>
                </div>
            </div>

        </div>
    </div>
    <div class="card-content">
        <table id="suppliers" class="table is-narrow">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Manifest No</th>
                    <th>Manifest Date</th>
                    <th>Lodgement No</th>

                    <?php if (app('laratrust')->hasRole('admin|operator')) : ?>

                    <th>Lodgement Date</th>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <?php if (app('laratrust')->hasRole('deliver')) : ?>
                    <th>B/E No</th>
                    <th>B/E Date</th>
                    <?php endif; // app('laratrust')->hasRole ?>
                    <th>Agent Name</th>

                    <?php if (app('laratrust')->hasRole('admin|operator|deliver')) : ?>
                    <th>Importer / Exporter</th>
                    <?php endif; // app('laratrust')->hasRole ?>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $file_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e(++$i); ?> </th>
                    <td><?php echo e($file_data->manifest_no); ?></td>
                    <td><?php echo e($file_data->manifest_date); ?></td>
                    <td><?php echo e($file_data->lodgement_no); ?></td>


                    <?php if (app('laratrust')->hasRole('admin|operator')) : ?>
                    <td><?php echo e($file_data->lodgement_date); ?></td>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <?php if (app('laratrust')->hasRole('deliver')) : ?>
                    <td><?php echo e($file_data->be_number); ?></td>
                    <td><?php echo e($file_data->be_date); ?></td>
                    <?php endif; // app('laratrust')->hasRole ?>
                    <td>
                        <?php if($file_data->agent): ?>
                        <?php echo e($file_data->agent->name); ?>

                        <?php endif; ?>
                    </td>

                    <?php if (app('laratrust')->hasRole('admin|operator|deliver')) : ?>
                    <td><?php echo e($file_data->ie_data->name ?? ''); ?></td>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <td><?php echo e($file_data->status); ?></td>

                    <td class="has-text-right">
                        <form action="<?php echo e(route('file_datas.destroy',$file_data->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <?php if (app('laratrust')->hasRole('admin')) : ?>
                                <a class="btn btn-info" href="<?php echo e(route('file_datas.edit', $file_data->id)); ?>">Edit</a>
                                <a class="btn btn-danger" href="<?php echo e(route('file_datas.destroy', $file_data->id)); ?>"
                                onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($file_data->id); ?>').submit();">
                                <i class="far fa-trash-alt"></i>
                                </a>

                                <form id="delete-form-<?php echo e($file_data->id); ?>" action="<?php echo e(route('file_datas.destroy', $file_data->id)); ?>" method="POST" style="display: none;">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                </form>
                            <?php endif; // app('laratrust')->hasRole ?>

                            <?php if (app('laratrust')->hasRole('operator')) : ?>
                                <?php if($file_data->status == 'Operated' || $file_data->status == 'Received'): ?>

                                    <a class="btn btn-info" href="<?php echo e(route('file_datas.edit', $file_data->id)); ?>">
                                            <?php if($file_data->status == 'Operated'): ?>
                                                Edit
                                            <?php else: ?>
                                                Operate
                                            <?php endif; ?>
                                    </a>

                                <?php endif; ?>
                            <?php endif; // app('laratrust')->hasRole ?>

                            <?php if (app('laratrust')->hasRole('deliver')) : ?>
                                <?php if($file_data->status != 'Received'): ?>
                                    <?php if($file_data->status == 'Operated'): ?>
                                        <a class="btn btn-info" href="<?php echo e(route('file_datas.edit', $file_data->id)); ?>">Deliver</a>
                                    <?php elseif($file_data->status == 'Printed'): ?>
                                        <a class="btn btn-danger" href="<?php echo e(route('file_datas.show', $file_data->id)); ?>">Print </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; // app('laratrust')->hasRole ?>




                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('#suppliers').DataTable();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/home.blade.php ENDPATH**/ ?>