<?php $__env->startSection('content'); ?>
    <div style="margin: 0 15%;">
        <div class="card card-accent-primary mb-3 text-left" style="">
            <div class="card-header">Add Update</div>
            <div class="card-body text-primary">

    <?php echo e(Form::model($ie_data, ['route' => ['ie_datas.update', $ie_data->id], 'method' => 'put','enctype' => 'multipart/form-data'])); ?>


                <?php echo e(csrf_field()); ?>


                <div class="row">

                    <div class="form-group col-6">
                        <?php echo e(Form::label('bin_no','BIN No:')); ?>


                        <?php echo e(Form::text('bin_no', null, ['class' => 'form-control', 'placeholder' => 'BIN No', 'required'])); ?>


                        <?php $__errorArgs = ['bin_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    <!-- Importer / Exporter Input Form -->
                    <div class="form-group col-6">
                        <?php echo e(Form::label('ie','Importer / Exporter: ')); ?> <br>
                        <div class="radio radio-inline">
                            <span> </span>
                            <label>
                                <?php echo e(Form::radio('ie', 'Importer', true)); ?> Importer
                            </label>
                            <label>
                                <?php echo e(Form::radio('ie', 'Exporter')); ?> Exporter
                            </label>

                        </div>
                    </div>

                    <div class="form-group col-6 ">
                        <?php echo e(Form::label('name', 'Importer / Exporter Name')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('name', null, array('class' => 'form-control', 'placeholder' => 'Importer / Exporter Name', 'required'  ))); ?>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group col-6 ">
                        <?php echo e(Form::label('owners_name', 'Owner / Manager Name')); ?>

                        <div class="input-group mb-3">
                            <?php echo e(Form::text('owners_name', null, array('class' => 'form-control', 'placeholder' => 'Owner Name', 'required'  ))); ?>

                            <?php $__errorArgs = ['owners_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <!-- Photo Input Form -->
                    <div class="form-group col-6">
                        <?php echo e(Form::label('photo','Photo:')); ?>

                        <?php echo e(Form::file('photo', null)); ?>

                        <p class="help-block"></p>
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <!-- Destination Input Form -->
                    <div class="form-group col-6">
                        <?php echo e(Form::label('destination','Destination:')); ?>


                        <?php echo e(Form::text('destination', null, ['class' => 'form-control', 'placeholder' => 'Destination', 'required'])); ?>


                        <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Destination Input Form -->
                    <div class="form-group col-6">
                        <?php echo e(Form::label('office_address','Agent / Office Address:')); ?>


                        <?php echo e(Form::text('office_address', null, ['class' => 'form-control', 'placeholder' => 'Office Address', 'required'])); ?>


                        <?php $__errorArgs = ['office_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Phone Number Input Form -->
                    <div class="form-group col-6">
                        <?php echo e(Form::label('phone','Phone Number:')); ?>


                        <?php echo e(Form::text('phone', null, ['class' => 'form-control', 'placeholder' => 'Agent Phone Number', 'required'])); ?>


                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Email Input Form -->
                    <div class="form-group col-6 ">
                        <?php echo e(Form::label('email','Email:')); ?>


                        <?php echo e(Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Email'])); ?>


                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <!-- Phone Number Input Form -->
                    <div class="form-group col-6">
                        <?php echo e(Form::label('house','House')); ?>


                        <?php echo e(Form::text('house', null, ['class' => 'form-control', 'placeholder' => 'Station / House', 'required'])); ?>


                        <?php $__errorArgs = ['house'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    <!-- Note Input Form -->
                    <div class="form-group col-12 d-none">
                        <?php echo e(Form::label('note','Note:')); ?>

                        <?php echo e(Form::textarea('note', null, ['class' => 'form-control', 'rows' =>5, 'placeholder' => 'Note'])); ?>

                    </div>

                    <hr>
                    <div class="col-12">
                        <div class="text-right">
                            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                        </div>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>


    </div>
  </div>
 </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>

    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DJ\laragon\www\CNF\resources\views/ie_datas/edit.blade.php ENDPATH**/ ?>