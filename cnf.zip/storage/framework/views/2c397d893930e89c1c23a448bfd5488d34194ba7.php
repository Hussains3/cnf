<?php $__env->startSection('content'); ?>

<div class="flex-container">
    <div class="columns m-t-10">
      <div class="column">
        <h1 class="title">Manage Users</h1>
      </div>
      <div class="column text-right">
        <a href="<?php echo e(route('gfiles.create')); ?>" class="btn btn-outline-primary">
            <i class="mdi mdi-account-edit"></i> Create GF Report</a>
      </div>
    </div>
    <hr class="m-t-0">

    <div class="card">
      <div class="card-content">
        <table class="table is-narrow">
          <thead>
            <tr>
              <th>id</th>
              <th>Assesment Date</th>
              <th>Green File</th>
              <th>Waiting Green file</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $gfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($gfile->id); ?></th>
                <td><?php echo e($gfile->assesmentDate); ?></td>
                <td><?php echo e($gfile->greenFile); ?></td>
                <td><?php echo e($gfile->waitingGreenFile); ?></td>
                <td class="has-text-right">
                    <a class="btn btn-outline-info" href="<?php echo e(route('gfiles.edit', $gfile->id)); ?>"> Edit</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div> <!-- end of .card -->

    
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/gfiles/index.blade.php ENDPATH**/ ?>