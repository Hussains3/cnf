

<?php $__env->startSection('content'); ?>

<div class="flex-container">
        <div class="columns m-t-10">
          <div class="column">
            <h1 class="title">View User Details</h1>
          </div> <!-- end of column -->
    
          <div class="column text-right">
            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-outline-primary">
                <i class="mdi mdi-account-edit"></i> Edit User</a>
          </div>
        </div>
        <hr class="m-t-0">
    
        <div class="columns">
          <div class="column">
            
            <div class="field">
              <label for="counter" class="label">Counter NO</label>
              <pre><?php echo e($user->counter); ?></pre>
            </div>

            <div class="field">
              <label for="name" class="label">Name</label>
              <pre><?php echo e($user->name); ?></pre>
            </div>
    
            <div class="field">
              <div class="field">
                <label for="email" class="label">Email</label>
                <pre><?php echo e($user->email); ?></pre>
              </div>
            </div>
    
            <div class="field">
              <div class="field">
                <label for="email" class="label">Roles</label>
                <ul>
                  <?php echo e($user->roles->count() == 0 ? 'This user has not been assigned any roles yet' : ''); ?>

                  <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($role->display_name); ?> (<?php echo e($role->description); ?>)</li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/manage/users/show.blade.php ENDPATH**/ ?>