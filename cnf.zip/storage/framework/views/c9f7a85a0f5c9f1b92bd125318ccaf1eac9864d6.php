<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col">
            <h2>Importer/Exporter List</h2>
        </div>
        <div class="col text-right">

            <a href="<?php echo e(route('ie_datas.create')); ?>" class="btn btn-primary">
                <i class="mdi mdi-account-edit"></i> New Importer/Exporter</a>
        </div>
    </div>

    <div class="card-content">
        <table id="agent" class="table is-narrow">
            <thead>
            <tr>
                <th>No</th>
                <th>BIN No</th>
                <th>IE Type</th>
                <th>Importer / Exporter Name</th>
                <th>Owner / Manager Name</th>
                <th>Photo</th>
                <th>Designation</th>
                <th>Office Address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>House</th>
                <th>Action</th>
            </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $ie_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ie_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <th><?php echo e(++$i); ?> </th>
                    <td><?php echo e($ie_data->bin_no); ?></td>
                    <td><?php echo e($ie_data->ie); ?></td>
                    <td><?php echo e($ie_data->name); ?></td>
                    <td><?php echo e($ie_data->owners_name); ?></td>
                    <td><a target="_blank" href="/<?php echo e($ie_data->photo); ?>"><img src="/<?php echo e($ie_data->photo); ?>" alt="" width="40"></a></td>
                    <td><?php echo e($ie_data->destination); ?></td>
                    <td><?php echo e($ie_data->office_address); ?></td>
                    <td><?php echo e($ie_data->phone); ?></td>
                    <td><?php echo e($ie_data->email); ?></td>
                    <td><?php echo e($ie_data->house); ?></td>
                    <td class="has-text-right">
                        

                        <form action="<?php echo e(route('ie_datas.destroy',$ie_data->id)); ?>" method="POST">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            
                            <?php if (app('laratrust')->hasRole('admin')) : ?>
                            <a class="btn btn-info" href="<?php echo e(route('ie_datas.edit', $ie_data->id)); ?>"> Edit</a>
                            <?php endif; // app('laratrust')->hasRole ?>




                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('#agent').DataTable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/ie_datas/index.blade.php ENDPATH**/ ?>