<?php $__env->startSection('content'); ?>

    <h2 id="tr" class="text-center">B/E Branch (Association) Custom House, Benapole</h2>
    <h2 id="tr" class="text-center">Work Report Sheet Per Day</h2>
    <div class="row card pdn">
        <div class="card-body">
            <?php echo Form::open(['route' => 'get_work_report', 'method' => 'post']); ?>

            <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-10">
                        <div class="form-group form-inline m-0">
                            <?php echo Form::label('target_date','Date'); ?>

                            <?php echo Form::date('target_date', $date , ['class'=>'form-control mx-2']); ?>

                            <?php echo Form::submit('Filter', ['class'=>'btn btn-primary mx-2','style'=>'padding: .3rem 1rem;']); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <button class="btn btn-md btn-info" onclick="printDiv('printMe')"> Print Report</button>
                    </div>
                </div>
            <?php echo Form::close(); ?>


        </div>
    </div>


    <?php if(!empty($work_sheet[0]) ): ?>
    <div id='printMe'>

    <table id="daily_report" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th class="text-center">Date:</th>
                <th class="text-center"><?php echo e(date('d-m',strtotime($date))); ?></th>
                <th class="text-center" colspan="2"><?php echo e(date('Y')); ?></th>
                <th class="text-center" colspan="4"></th>
                <th class="text-center"></th>
                <th class="text-center"></th>
                <th class="text-center"></th>
                <th class="text-center"></th>
                <th class="text-center" colspan="2"></th>
                <th class="text-center"></th>
            </tr>
        </thead>
        <?php $__currentLoopData = $work_sheet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center">No</td>
            <td class="text-center" colspan="13"><?php echo e($file_data->name); ?></td>
            <td class="text-center">Total</td>
        </tr>
        <tr>
            <td class="text-center align-middle" rowspan="2" class="align-middle text-center align-items-center"><?php echo e($i++); ?></td>
            <td class="text-center">Item 1</td>
            <td class="text-center" colspan="2">Item 2-4</td>
            <td class="text-center" colspan="2">Item 5-7</td>
            <td class="text-center" colspan="2">Item 8-9</td>
            <td class="text-center" colspan="2">Item 10 +</td>
            <td class="text-center" colspan="2">Note</td>
            <td class="text-center" colspan="2">Pages</td>
            <td class="text-center align-middle" rowspan="3"><?php echo e($totalFileData[] = $file_data->total); ?></td>
        </tr>
        <tr>
            <td class="text-center"><?php echo e($file_data->item_1); ?></td>
            <td class="text-center" colspan="2"><?php echo e($file_data->item_2_4); ?></td>
            <td class="text-center" colspan="2"><?php echo e($file_data->item_5_7); ?></td>
            <td class="text-center" colspan="2"><?php echo e($file_data->item_8_9); ?></td>
            <td class="text-center" colspan="2"><?php echo e($file_data->item_10); ?></td>
            <td class="text-center" colspan="2"></td>
            <td class="text-center" colspan="2"><?php echo e($totalFilePages[] = $file_data->total_pages); ?></td>
        </tr>
        <tr>
            <td class="text-center" colspan="2" class="text-center">Item Numbers</td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tfoot>

        <tr class="">
            <th class="text-center"  colspan="2"></th>
            <th class="text-center"  colspan="3">Alltotal</th>
            <th class="text-center"  colspan="3"><?php echo e(array_sum($totalFilePages)); ?></th>
            <th class="text-center" >(+)</th>
            <th class="text-center" >0</th>
            <th class="text-center" >(=)</th>
            <th class="text-center"  colspan="3"><?php echo e(array_sum($totalFilePages)); ?></th>
            <th class="text-center" ><?php echo e(array_sum($totalFileData)); ?></th>
        </tr>
        </tfoot>
    </table>
    </div>
    <?php else: ?>
        <h3 class="text-center">No data Found On this date</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;

    }
</script>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/reports/work_report.blade.php ENDPATH**/ ?>