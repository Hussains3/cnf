<?php $__env->startSection('content'); ?>

    <h2 id="tr" class="text-center">Monthly Final Report</h2>

    <table id="monthly_final_report" class="table table-striped table-bordered " style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Day</th>
                <th>Files</th>
                <th>Pages</th>
                <th>Avarage</th>
                <th>Holiday</th>
                <th>Ave. Total</th>
                <th>Work Point</th>
                <th>%</th>
                <th>Add</th>
                <th>Final%</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $userSalary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <tr>
                <?php
                $file = $item->totalFile;
                $page = $item->totalPage;
                    $day = $item->day - $item->holiday;
                    $average = ($item->totalFile)/$day;
                    $avgTotal = ($average * $item->holiday) + $item->totalFile;
                    $wp = ((((($page / $day) * $item->holiday) + $page) - $avgTotal)/2) + $avgTotal;
                    $parcent = (100 * $wp) / $totalWorkPoint;
                ?>
                <th><?php echo e($item->name); ?></th>
                <th><?php echo e($day); ?></th>
                <th><?php echo e($file); ?></th>
                <th><?php echo e($page); ?></th>
                <th><?php echo e(round($average,2)); ?></th>
                <th><?php echo e($item->holiday); ?></th>
                <th><?php echo e(round($avgTotal,2)); ?></th>
                <th><?php echo e(round($wp,2)); ?></th>
                <th><?php echo e(round($parcent,2)); ?></th>
                <th><?php echo e(80); ?></th>
                <th><?php echo e(round($parcent + 80,2)); ?></th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        <tfoot>
            <tr>
                <th>Total</th>
                <th></th>
                <th>total file</th>
                <th>total page</th>
                <th></th>
                <th></th>
                <th></th>
                <th><?php echo e(round($totalWorkPoint,2)); ?></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        </tfoot>
    </table>

    <div class="sig-sec mt-5">
        <h5>Signeture Of Working Person</h5>
        <table class="table table-striped table-bordered " style="width:50%">
            <thead>
                <tr>
                    <th>Se. No</th>
                    <th>Name</th>
                    <th>Result</th>
                    <th colspan="2">Signeture</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $rankList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rankItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($rankItem['name']); ?></td>
                    <td>
                        <?php if($key == 0): ?>
                            <?php echo e($key + 1); ?>st
                        <?php elseif($key == 1): ?>
                            <?php echo e($key + 1); ?>nd
                        <?php elseif($key == 2): ?>
                            <?php echo e($key + 1); ?>rd
                        <?php else: ?>
                            <?php echo e($key + 1); ?>th
                        <?php endif; ?>
                    </td>
                    <td colspan="2"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.20/filtering/row-based/range_dates.js"></script>

    <script !src="">

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/reports/monthly_final_report.blade.php ENDPATH**/ ?>