<?php $__env->startSection('content'); ?>
    <div style="margin: 0 15%;">
        <div class="card card-accent-primary mb-3 text-left" style="">
            <div class="card-header">Edit Green File</div>
            <div class="card-body text-primary">

            <?php echo Form::open(['route' => ['gfiles.create'], 'method' => 'post', 'enctype' => 'multipart/form-data' ]); ?>


            <?php echo e(csrf_field()); ?>


            <div class="row">

                <div class="form-group col-12">
                    <?php echo e(Form::label('assesmentDate','Assesment Date')); ?>

                    <?php echo Form::date('assesmentDate ', null, ['class' => 'form-control','required','readonly']); ?>


                    <?php $__errorArgs = ['gfile_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-group col-12">
                    <?php echo e(Form::label('greenFile','Green File')); ?>

                    <?php echo Form::number('greenFile',null, ['class' => 'form-control', 'placeholder' => '00', 'required']); ?>


                    <?php $__errorArgs = ['gfile_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-group col-12">
                    <?php echo e(Form::label('waitingGreenFile','Waiting Green File')); ?>

                    <?php echo Form::number('waitingGreenFile', null, ['class' => 'form-control', 'placeholder' => '00', 'required']); ?>


                    <?php $__errorArgs = ['gfile_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <hr>
                <div class="col-12">
                    <div class="text-right">
                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>


            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cnf\resources\views/gfiles/edit.blade.php ENDPATH**/ ?>