<?php

namespace App\Http\Controllers;

use App\Models\Data_user;
use Illuminate\Http\Request;

class DataUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Data_user  $data_user
     * @return \Illuminate\Http\Response
     */
    public function show(Data_user $data_user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Data_user  $data_user
     * @return \Illuminate\Http\Response
     */
    public function edit(Data_user $data_user)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Data_user  $data_user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Data_user $data_user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Data_user  $data_user
     * @return \Illuminate\Http\Response
     */
    public function destroy(Data_user $data_user)
    {
        //
    }
}
